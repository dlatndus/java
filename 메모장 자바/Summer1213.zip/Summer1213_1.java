public class Summer1213_1{
	public static void main(String args[]){
		int num=2;
		switch(num){
			case 1 : System.out.println("Ȧ"); break;
			case 2 : System.out.println("¦"); break;
		}
	}
}